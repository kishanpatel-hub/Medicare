package Medicare.model;

public enum gender {
	Male,Female;
}
