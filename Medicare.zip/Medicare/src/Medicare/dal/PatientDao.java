package Medicare.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import Medicare.model.Patient;



public class PatientDao {
	protected ConnectionManager connectionManager;

	private static PatientDao instance = null;
	protected PatientDao() {
		connectionManager = new ConnectionManager();
	}
	public static PatientDao getInstance() {
		if(instance == null) {
			instance = new PatientDao();
		}
		return instance;
	}

	public Patient create(Patient patient) throws SQLException {
		String insertPatient =
			"INSERT INTO patient(First_Name, Last_Name, Age, Gender, Phone, Street, City," +  
			"ZIP, DOB, BloodGroup, Height, Weight, Policy_No, InsCom_ID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		ResultSet resultKey = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertPatient,
				Statement.RETURN_GENERATED_KEYS);
			insertStmt.setString(1, patient.getFirst_name());
			insertStmt.setString(2, patient.getLast_name());
			insertStmt.setInt(3, patient.getAge());
			insertStmt.setString(4, patient.getGender().name());
			insertStmt.setString(5, patient.getPhone());
			insertStmt.setString(6, patient.getStreet());
			insertStmt.setString(7, patient.getCity());
			insertStmt.setString(8, patient.getZip());
			insertStmt.setTimestamp(9, new Timestamp(patient.getDob().getTime()));
			insertStmt.setString(10, patient.getBloodgroup());
			insertStmt.setInt(11, patient.getHeight());
			insertStmt.setInt(12, patient.getWeight());
			insertStmt.setLong(13, patient.getPolicy_no());
			insertStmt.setInt(14, patient.getInsCom().getInsCom_ID());
			insertStmt.executeUpdate();
			
			// Retrieve the auto-generated key and set it, so it can be used by the caller.
			resultKey = insertStmt.getGeneratedKeys();
			int patientId = -1;
			if(resultKey.next()) {
				patientId = resultKey.getInt(1);
			} else {
				throw new SQLException("Unable to retrieve auto-generated key.");
			}
			patient.setPatient_ID(patientId);
			return patient;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(insertStmt != null) {
				insertStmt.close();
			}
			if(resultKey != null) {
				resultKey.close();
			}
		}
	}

}
